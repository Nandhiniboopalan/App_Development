package com.zos.config;

public class SecurityContest {
	
	public static final String JWT_KEY="zjdbfagvqruuyzbhgdfpeoajnebxiueban";
	public static final String HEADER="Authorization";
//	public static final String HEADER = null;

}
