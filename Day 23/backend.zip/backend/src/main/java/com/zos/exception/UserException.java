package com.zos.exception;

public class UserException extends Exception {
	
	public UserException() {
		// TODO Auto-generated constructor stub
	}
	
	public UserException(String message) {
		super(message);
	}

}
